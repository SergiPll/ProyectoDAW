export const environment = {
  firebase: {
    projectId: 'aeol-77555',
    appId: '1:735789578255:web:d2bb9fd9db1bbb79b64b7a',
    databaseURL: 'https://aeol-77555-default-rtdb.europe-west1.firebasedatabase.app',
    storageBucket: 'aeol-77555.appspot.com',
    apiKey: 'AIzaSyDPjMn6_TUnWKwxY6iIbgR_MCf2XpCkaTg',
    authDomain: 'aeol-77555.firebaseapp.com',
    messagingSenderId: '735789578255',
    measurementId: 'G-RV4KPYSRHK',
  },
  production: true
};
