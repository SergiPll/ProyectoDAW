// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'aeol-77555',
    appId: '1:735789578255:web:d2bb9fd9db1bbb79b64b7a',
    databaseURL: 'https://aeol-77555-default-rtdb.europe-west1.firebasedatabase.app',
    storageBucket: 'aeol-77555.appspot.com',
    apiKey: 'AIzaSyDPjMn6_TUnWKwxY6iIbgR_MCf2XpCkaTg',
    authDomain: 'aeol-77555.firebaseapp.com',
    messagingSenderId: '735789578255',
    measurementId: 'G-RV4KPYSRHK',
  },
  production: false,
  idioma: "ES",
  firebaseConfig: {
    apiKey: "AIzaSyDPjMn6_TUnWKwxY6iIbgR_MCf2XpCkaTg",
    authDomain: "aeol-77555.firebaseapp.com",
    projectId: "aeol-77555",
    storageBucket: "aeol-77555.appspot.com",
    messagingSenderId: "735789578255",
    appId: "1:735789578255:web:d2bb9fd9db1bbb79b64b7a",
    measurementId: "G-RV4KPYSRHK"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
