import { Component, OnInit } from '@angular/core';
import ES from '../../../assets/shared/ES.json';
import EN from '../../../assets/shared/EN.json';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  
  //Si el idioma es True, sera español. Si es False, sera Ingles.
  public idioma: boolean = true;
  public paginas: string[] = ["product", "act", "contact"]
  public palabras: any;

  constructor() {
    this.palabras = ES;
  }

  ngOnInit(): void {
  }

  cambioIdioma(e: MouseEvent) {
    // Comprobar el booleano del idioma para saber si esta en ingles o espanyol
    if (this.idioma) {
      this.palabras = EN;
      this.idioma = !this.idioma;
      environment.idioma = "EN";
    } else {
      this.palabras = ES;
      this.idioma = !this.idioma;
      environment.idioma = "ES";
    }
  }
}
