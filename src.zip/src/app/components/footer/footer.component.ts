import { Component, OnInit } from '@angular/core';
import ES from '../../../assets/shared/ES.json';
import EN from '../../../assets/shared/EN.json';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {

  public idioma: boolean = true;
  public palabras: any;

  constructor() {
    if (environment.idioma == "ES") {
      this.palabras = ES;
    } else {
      this.palabras = EN;
    }
  }

  ngOnInit(): void {
  }

}