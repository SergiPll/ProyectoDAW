import { Component, OnInit } from '@angular/core';
import ES from '../../../assets/shared/ES.json';
import { initializeApp } from "firebase/app";
import { getFirestore, collection, getDocs } from 'firebase/firestore/lite';

@Component({
  selector: 'app-act',
  templateUrl: './act.component.html',
  styleUrls: ['./act.component.css']
})
export class ActComponent implements OnInit {

  public palabras: any;
  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  firebaseConfig = {
    apiKey: "AIzaSyDPjMn6_TUnWKwxY6iIbgR_MCf2XpCkaTg",
    authDomain: "aeol-77555.firebaseapp.com",
    databaseURL: "https://aeol-77555-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "aeol-77555",
    storageBucket: "aeol-77555.appspot.com",
    messagingSenderId: "735789578255",
    appId: "1:735789578255:web:d2bb9fd9db1bbb79b64b7a",
    measurementId: "G-RV4KPYSRHK"
  };

  app = initializeApp(this.firebaseConfig);
  db = getFirestore(this.app);

  constructor() {
    this.palabras = ES;
  }

  ngOnInit(): void {
    this.getActs(this.db);
  }

  async getActs(db: any) {
    const actsCol = collection(db, 'acts');
    const actsSnapshot = await getDocs(actsCol);
    const actsList: any = actsSnapshot.docs.map(doc => doc.data());
    console.log(actsList);
    // Devuelve una matriz. Si se hace "actsList[0]" + "[Desc]" o "[Version]", sacara la descripcion o version de cada posicion.
    return actsList;
  }

}