import { Component, OnInit } from '@angular/core';
import ES from '../../../assets/shared/ES.json';
import EN from '../../../assets/shared/EN.json';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  public palabras: any;

  constructor() { 
    this.palabras = ES;
  }

  ngOnInit(): void {
  }

}
