import { Component, OnInit } from '@angular/core';
import ES from '../../../assets/shared/ES.json';
import EN from '../../../assets/shared/EN.json';
import { FormBuilder } from '@angular/forms';
import { getFirestore, collection, addDoc} from 'firebase/firestore/lite';
import { initializeApp } from "firebase/app";


@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  firebaseConfig = {
    apiKey: "AIzaSyDPjMn6_TUnWKwxY6iIbgR_MCf2XpCkaTg",
    authDomain: "aeol-77555.firebaseapp.com",
    databaseURL: "https://aeol-77555-default-rtdb.europe-west1.firebasedatabase.app",
    projectId: "aeol-77555",
    storageBucket: "aeol-77555.appspot.com",
    messagingSenderId: "735789578255",
    appId: "1:735789578255:web:d2bb9fd9db1bbb79b64b7a",
    measurementId: "G-RV4KPYSRHK"
  };

  app = initializeApp(this.firebaseConfig);
  db = getFirestore(this.app);
  grupoForm: any = this.formBuilder.group({
    correo: '',
    mensaje: ''
  });

  public palabras: any;

  constructor(private formBuilder: FormBuilder) {
    this.palabras = ES;
  }

  ngOnInit(): void {
  }

  onSubmit(): void {

    // Comprobar si el form es válido  y si lo es
    // anyadir data

    this.addCorreo(this.grupoForm.value);

    //console.log(this.grupoForm);

    // Process checkout data here
    // console.warn('Se han enviado los datos:', this.grupoForm.value);
    this.grupoForm.reset();
  }

  addCorreo(data: any) {
    const correoRef = collection(this.db, 'contacto');
    return addDoc(correoRef, { correo: data['correo'], mensaje: data['mensaje'] });
  }


}
