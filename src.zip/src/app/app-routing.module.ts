import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ActComponent } from './views/act/act.component';
import { ContactComponent } from './views/contact/contact.component';
import { ProductComponent } from './views/product/product.component';

const routes: Routes = [
  {path:'', redirectTo:'product', pathMatch:'full'},
  {path:'act', component: ActComponent},
  {path:'contact', component: ContactComponent},  
  {path:'product', component: ProductComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
